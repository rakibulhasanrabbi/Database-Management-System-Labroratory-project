-- ============================================================
-- Free Medicine Distribution Management System
-- MySQL Database Setup (for XAMPP / Web App)
-- Member 2: Authentication + Shared Backend
-- ============================================================

CREATE DATABASE IF NOT EXISTS free_medicine_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE free_medicine_db;

-- ============================================================
-- TABLE: Users (Citizens / Recipients)
-- ============================================================
CREATE TABLE IF NOT EXISTS Users (
    UserID      INT AUTO_INCREMENT PRIMARY KEY,
    FullName    VARCHAR(100)    NOT NULL,
    Phone       VARCHAR(15)     NOT NULL,
    Email       VARCHAR(100)    NOT NULL UNIQUE,
    Password    VARCHAR(255)    NOT NULL,
    Address     VARCHAR(255),
    CreatedAt   DATETIME        DEFAULT CURRENT_TIMESTAMP,
    Status      VARCHAR(20)     DEFAULT 'active'
);

-- ============================================================
-- TABLE: Donors
-- ============================================================
CREATE TABLE IF NOT EXISTS Donors (
    DonorID     INT AUTO_INCREMENT PRIMARY KEY,
    DonorName   VARCHAR(100)    NOT NULL,
    Phone       VARCHAR(15)     NOT NULL,
    Email       VARCHAR(100)    NOT NULL UNIQUE,
    Password    VARCHAR(255)    NOT NULL,
    Address     VARCHAR(255),
    DonorType   VARCHAR(50)     DEFAULT 'Individual',
    CreatedAt   DATETIME        DEFAULT CURRENT_TIMESTAMP,
    Status      VARCHAR(20)     DEFAULT 'active'
);

-- ============================================================
-- TABLE: Admins
-- ============================================================
CREATE TABLE IF NOT EXISTS Admins (
    AdminID     INT AUTO_INCREMENT PRIMARY KEY,
    AdminName   VARCHAR(100)    NOT NULL,
    Phone       VARCHAR(15),
    Email       VARCHAR(100)    NOT NULL UNIQUE,
    Password    VARCHAR(255)    NOT NULL,
    Role        VARCHAR(50)     DEFAULT 'admin',
    CreatedAt   DATETIME        DEFAULT CURRENT_TIMESTAMP,
    Status      VARCHAR(20)     DEFAULT 'active'
);

-- ============================================================
-- TABLE: DeliveryRiders
-- ============================================================
CREATE TABLE IF NOT EXISTS DeliveryRiders (
    RiderID     INT AUTO_INCREMENT PRIMARY KEY,
    RiderName   VARCHAR(100)    NOT NULL,
    Phone       VARCHAR(15)     NOT NULL,
    Email       VARCHAR(100)    NOT NULL UNIQUE,
    Password    VARCHAR(255)    NOT NULL,
    Address     VARCHAR(255),
    CreatedAt   DATETIME        DEFAULT CURRENT_TIMESTAMP,
    Status      VARCHAR(20)     DEFAULT 'active'
);

-- ============================================================
-- TABLE: MedicineCategories
-- ============================================================
CREATE TABLE IF NOT EXISTS MedicineCategories (
    CategoryID      INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName    VARCHAR(100)    NOT NULL,
    Description     VARCHAR(255)
);

-- ============================================================
-- TABLE: Medicines
-- ============================================================
CREATE TABLE IF NOT EXISTS Medicines (
    MedicineID              INT AUTO_INCREMENT PRIMARY KEY,
    MedicineName            VARCHAR(100)    NOT NULL,
    GenericName             VARCHAR(100),
    BrandName               VARCHAR(100),
    CategoryID              INT,
    UnitType                VARCHAR(50),
    Description             VARCHAR(255),
    RequiresPrescription    TINYINT(1)      DEFAULT 0,
    FOREIGN KEY (CategoryID) REFERENCES MedicineCategories(CategoryID)
);

-- ============================================================
-- TABLE: Donations
-- ============================================================
CREATE TABLE IF NOT EXISTS Donations (
    DonationID      INT AUTO_INCREMENT PRIMARY KEY,
    DonorID         INT             NOT NULL,
    DonationDate    DATETIME        DEFAULT CURRENT_TIMESTAMP,
    DonationStatus  VARCHAR(20)     DEFAULT 'Pending',
    AdminID         INT,
    Remarks         VARCHAR(255),
    FOREIGN KEY (DonorID)   REFERENCES Donors(DonorID),
    FOREIGN KEY (AdminID)   REFERENCES Admins(AdminID)
);

-- ============================================================
-- TABLE: DonationItems
-- ============================================================
CREATE TABLE IF NOT EXISTS DonationItems (
    DonationItemID  INT AUTO_INCREMENT PRIMARY KEY,
    DonationID      INT     NOT NULL,
    MedicineID      INT     NOT NULL,
    Quantity        INT     NOT NULL,
    ExpiryDate      DATE,
    BatchNo         VARCHAR(50),
    ManufactureDate DATE,
    FOREIGN KEY (DonationID)    REFERENCES Donations(DonationID),
    FOREIGN KEY (MedicineID)    REFERENCES Medicines(MedicineID)
);

-- ============================================================
-- TABLE: Requests
-- ============================================================
CREATE TABLE IF NOT EXISTS Requests (
    RequestID           INT AUTO_INCREMENT PRIMARY KEY,
    UserID              INT             NOT NULL,
    RequestDate         DATETIME        DEFAULT CURRENT_TIMESTAMP,
    RequestStatus       VARCHAR(20)     DEFAULT 'Pending',
    AdminID             INT,
    PrescriptionFile    VARCHAR(255),
    UrgencyLevel        VARCHAR(20)     DEFAULT 'Low',
    Remarks             VARCHAR(255),
    FOREIGN KEY (UserID)    REFERENCES Users(UserID),
    FOREIGN KEY (AdminID)   REFERENCES Admins(AdminID)
);

-- ============================================================
-- TABLE: RequestItems
-- ============================================================
CREATE TABLE IF NOT EXISTS RequestItems (
    RequestItemID       INT AUTO_INCREMENT PRIMARY KEY,
    RequestID           INT     NOT NULL,
    MedicineID          INT     NOT NULL,
    RequestedQuantity   INT     NOT NULL,
    ApprovedQuantity    INT     DEFAULT 0,
    FOREIGN KEY (RequestID)     REFERENCES Requests(RequestID),
    FOREIGN KEY (MedicineID)    REFERENCES Medicines(MedicineID)
);

-- ============================================================
-- TABLE: Inventory
-- ============================================================
CREATE TABLE IF NOT EXISTS Inventory (
    InventoryID         INT AUTO_INCREMENT PRIMARY KEY,
    MedicineID          INT         NOT NULL UNIQUE,
    AvailableQuantity   INT         DEFAULT 0,
    LastUpdated         DATETIME    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (MedicineID)    REFERENCES Medicines(MedicineID)
);

-- ============================================================
-- TABLE: PickupPoints
-- ============================================================
CREATE TABLE IF NOT EXISTS PickupPoints (
    PickupPointID   INT AUTO_INCREMENT PRIMARY KEY,
    PointName       VARCHAR(100)    NOT NULL,
    Address         VARCHAR(255),
    Phone           VARCHAR(15),
    ManagerName     VARCHAR(100)
);

-- ============================================================
-- TABLE: Distribution
-- ============================================================
CREATE TABLE IF NOT EXISTS Distribution (
    DistributionID      INT AUTO_INCREMENT PRIMARY KEY,
    RequestID           INT             NOT NULL,
    DistributionDate    DATETIME        DEFAULT CURRENT_TIMESTAMP,
    DistributionMethod  VARCHAR(50)     DEFAULT 'Pickup',
    DeliveryStatus      VARCHAR(20)     DEFAULT 'Pending',
    AdminID             INT,
    PickupPointID       INT,
    ReceiverName        VARCHAR(100),
    ReceiverPhone       VARCHAR(15),
    FOREIGN KEY (RequestID)     REFERENCES Requests(RequestID),
    FOREIGN KEY (AdminID)       REFERENCES Admins(AdminID),
    FOREIGN KEY (PickupPointID) REFERENCES PickupPoints(PickupPointID)
);

-- ============================================================
-- TABLE: Notifications (Member 2 addition)
-- ============================================================
CREATE TABLE IF NOT EXISTS Notifications (
    NotificationID  INT AUTO_INCREMENT PRIMARY KEY,
    UserType        VARCHAR(20)     NOT NULL,   -- 'user', 'donor', 'admin', 'rider'
    UserID          INT             NOT NULL,
    Message         VARCHAR(500)    NOT NULL,
    IsRead          TINYINT(1)      DEFAULT 0,
    CreatedAt       DATETIME        DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- DEFAULT ADMIN ACCOUNT (password: admin123)
-- ============================================================
INSERT INTO Admins (AdminName, Phone, Email, Password, Role, Status)
VALUES ('Super Admin', '01700000000', 'admin@medicine.com',
        '$2y$10$IryDl3.aZ7.JlFgm3vWIm.pDMo0ydGBrtZ1R5vfe/VAKWNS1t0iwa', 'super_admin', 'active');

-- ============================================================
-- SAMPLE MEDICINE CATEGORIES
-- ============================================================
INSERT INTO MedicineCategories (CategoryName, Description) VALUES
('Antibiotic',      'Medicines that fight bacterial infections'),
('Painkiller',      'Medicines for pain relief'),
('Antidiabetic',    'Medicines for diabetes management'),
('Cardiovascular',  'Medicines for heart and blood pressure'),
('Vitamin',         'Vitamins and supplements');

-- ============================================================
-- Tables from ER Diagram (Rider Section)
-- ============================================================

CREATE TABLE IF NOT EXISTS Delivery_System (
    delivery_system_id INT AUTO_INCREMENT PRIMARY KEY,
    time TIME,
    tracking_status VARCHAR(50),
    date DATE,
    pick_up VARCHAR(255),
    drop_off VARCHAR(255),
    recipient_id INT
);

CREATE TABLE IF NOT EXISTS Rider_System_Initiation (
    delivery_rider_id INT,
    delivery_system_id INT,
    PRIMARY KEY (delivery_rider_id, delivery_system_id)
);

CREATE TABLE IF NOT EXISTS Medicine_Dispatch (
    dispatch_id INT AUTO_INCREMENT PRIMARY KEY,
    delivery_rider_id INT,
    stock_id INT,
    Time TIME,
    Date DATE,
    Comment VARCHAR(255)
);
