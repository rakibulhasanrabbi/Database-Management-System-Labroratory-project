<?php
// ============================================================
// admin/requests.php
// Citizen Request Management
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'admin') {
    redirect('/free_medicine/free_medicine/login.php');
}

$adminId = $_SESSION['user_id'];

// Handle Approve / Reject
if (isset($_POST['action'])) {
    $reqId = $_POST['request_id'];
    $status = $_POST['action'] === 'approve' ? 'Approved' : 'Rejected';
    
    // Update Request Status
    $stmt = $pdo->prepare("UPDATE requests SET RequestStatus = ?, AdminID = ? WHERE RequestID = ?");
    $stmt->execute([$status, $adminId, $reqId]);

    // If approved, create a Distribution record automatically
    if ($status === 'Approved') {
        // Get user details
        $usrStmt = $pdo->prepare("SELECT u.FullName, u.Phone FROM requests r JOIN users u ON r.UserID = u.UserID WHERE r.RequestID = ?");
        $usrStmt->execute([$reqId]);
        $user = $usrStmt->fetch();

        // Check if distribution already exists
        $chk = $pdo->prepare("SELECT COUNT(*) FROM distribution WHERE RequestID = ?");
        $chk->execute([$reqId]);
        if ($chk->fetchColumn() == 0) {
            $distStmt = $pdo->prepare("INSERT INTO distribution (RequestID, DistributionMethod, AdminID, ReceiverName, ReceiverPhone) VALUES (?, 'Delivery', ?, ?, ?)");
            $distStmt->execute([$reqId, $adminId, $user['FullName'], $user['Phone']]);
        }
    }
    
    redirect('/free_medicine/free_medicine/admin/requests.php?msg=updated');
}

$requests = $pdo->query("
    SELECT r.*, u.FullName, u.Phone 
    FROM requests r
    JOIN users u ON r.UserID = u.UserID
    ORDER BY r.RequestDate DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Citizen Requests — Admin Panel</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar">
    <div class="navbar-brand"><i class="fas fa-shield-alt"></i> Admin Panel</div>
    <div class="navbar-user">
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <aside class="sidebar">
        <div class="sidebar-label">Admin Menu</div>
        <a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="users.php"><i class="fas fa-users"></i> Users & Roles</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="requests.php" class="active"><i class="fas fa-hand-holding-medical"></i> Citizen Requests</a>
        <a href="donations.php"><i class="fas fa-box-open"></i> Donations</a>
    </aside>

    <main class="main-content">
        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">Request status updated successfully.</div>
        <?php endif; ?>

        <div class="card">
            <h2 class="card-title"><i class="fas fa-hand-holding-medical"></i> Citizen Medicine Requests</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Citizen Name</th>
                        <th>Date</th>
                        <th>Urgency</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $r): ?>
                        <tr>
                            <td>#<?= $r['RequestID'] ?></td>
                            <td><?= htmlspecialchars($r['FullName']) ?><br><small><?= htmlspecialchars($r['Phone']) ?></small></td>
                            <td><?= date('M d, Y', strtotime($r['RequestDate'])) ?></td>
                            <td style="color: <?= $r['UrgencyLevel']=='High'?'red':'inherit' ?>; font-weight:bold;"><?= htmlspecialchars($r['UrgencyLevel']) ?></td>
                            <td>
                                <span class="badge <?= $r['RequestStatus'] == 'Approved' ? 'badge-approved' : ($r['RequestStatus'] == 'Rejected' ? 'badge-rejected' : 'badge-pending') ?>">
                                    <?= htmlspecialchars($r['RequestStatus']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if($r['RequestStatus'] === 'Pending'): ?>
                                <form method="POST" style="display:flex; gap:5px;">
                                    <input type="hidden" name="request_id" value="<?= $r['RequestID'] ?>">
                                    <button type="submit" name="action" value="approve" class="btn btn-primary" style="padding:4px 8px; font-size:12px;">Approve</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger" style="padding:4px 8px; font-size:12px;">Reject</button>
                                </form>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
