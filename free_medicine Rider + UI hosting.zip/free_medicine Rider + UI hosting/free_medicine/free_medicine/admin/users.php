<?php
// ============================================================
// admin/users.php
// User Management
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'admin') {
    redirect('/free_medicine/free_medicine/login.php');
}

// Handle User Status Update
if (isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    $table = $_POST['table'] ?? '';
    $id = $_POST['id'] ?? 0;
    $newStatus = $_POST['status'] === 'active' ? 'inactive' : 'active';
    
    if ($table === 'users') {
        $stmt = $pdo->prepare("UPDATE users SET Status = ? WHERE UserID = ?");
        $stmt->execute([$newStatus, $id]);
    } elseif ($table === 'donors') {
        $stmt = $pdo->prepare("UPDATE donors SET Status = ? WHERE DonorID = ?");
        $stmt->execute([$newStatus, $id]);
    } elseif ($table === 'riders') {
        $stmt = $pdo->prepare("UPDATE deliveryriders SET Status = ? WHERE RiderID = ?");
        $stmt->execute([$newStatus, $id]);
    }
    redirect('/free_medicine/free_medicine/admin/users.php');
}

$users = $pdo->query("SELECT UserID as ID, FullName as Name, Email, 'citizen' as Role, Status, 'users' as Tbl FROM users")->fetchAll();
$donors = $pdo->query("SELECT DonorID as ID, DonorName as Name, Email, 'donor' as Role, Status, 'donors' as Tbl FROM donors")->fetchAll();
$riders = $pdo->query("SELECT RiderID as ID, RiderName as Name, Email, 'rider' as Role, Status, 'riders' as Tbl FROM deliveryriders")->fetchAll();

$allUsers = array_merge($users, $donors, $riders);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Users — Admin Panel</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar">
    <div class="navbar-brand"><i class="fas fa-shield-alt"></i> Admin Panel</div>
    <div class="navbar-user">
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <aside class="sidebar">
        <div class="sidebar-label">Admin Menu</div>
        <a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="users.php" class="active"><i class="fas fa-users"></i> Users & Roles</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="requests.php"><i class="fas fa-hand-holding-medical"></i> Citizen Requests</a>
        <a href="donations.php"><i class="fas fa-box-open"></i> Donations</a>
    </aside>

    <main class="main-content">
        <div class="card">
            <h2 class="card-title"><i class="fas fa-users"></i> All Platform Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($allUsers as $u): ?>
                        <tr>
                            <td><?= htmlspecialchars($u['Name']) ?></td>
                            <td><?= htmlspecialchars($u['Email']) ?></td>
                            <td style="text-transform: capitalize;"><?= htmlspecialchars($u['Role'] ?? 'Citizen') ?></td>
                            <td>
                                <span class="badge <?= $u['Status'] === 'active' ? 'badge-active' : 'badge-inactive' ?>">
                                    <?= htmlspecialchars($u['Status']) ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="table" value="<?= $u['Tbl'] ?>">
                                    <input type="hidden" name="id" value="<?= $u['ID'] ?>">
                                    <input type="hidden" name="status" value="<?= $u['Status'] ?>">
                                    <button type="submit" class="btn <?= $u['Status'] === 'active' ? 'btn-danger' : 'btn-primary' ?>" style="padding:4px 8px; font-size:12px;">
                                        <?= $u['Status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
