<?php
// ============================================================
// admin/donations.php
// Donor Request Management
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'admin') {
    redirect('/free_medicine/free_medicine/login.php');
}

$adminId = $_SESSION['user_id'];

// Handle Approve / Reject
if (isset($_POST['action'])) {
    $donId = $_POST['donation_id'];
    $status = $_POST['action'] === 'approve' ? 'Approved' : 'Rejected';
    
    $stmt = $pdo->prepare("UPDATE donations SET DonationStatus = ?, AdminID = ? WHERE DonationID = ?");
    $stmt->execute([$status, $adminId, $donId]);

    // If approved, optionally logic to add items to inventory...
    // For now we just update the status.
    
    redirect('/free_medicine/free_medicine/admin/donations.php?msg=updated');
}

$donations = $pdo->query("
    SELECT d.*, u.DonorName, u.Phone 
    FROM donations d
    JOIN donors u ON d.DonorID = u.DonorID
    ORDER BY d.DonationDate DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Donations — Admin Panel</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar">
    <div class="navbar-brand"><i class="fas fa-shield-alt"></i> Admin Panel</div>
    <div class="navbar-user">
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <aside class="sidebar">
        <div class="sidebar-label">Admin Menu</div>
        <a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="users.php"><i class="fas fa-users"></i> Users & Roles</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="requests.php"><i class="fas fa-hand-holding-medical"></i> Citizen Requests</a>
        <a href="donations.php" class="active"><i class="fas fa-box-open"></i> Donations</a>
    </aside>

    <main class="main-content">
        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">Donation status updated successfully.</div>
        <?php endif; ?>

        <div class="card">
            <h2 class="card-title"><i class="fas fa-box-open"></i> Medicine Donations</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Donor Name</th>
                        <th>Date</th>
                        <th>Remarks</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($donations as $d): ?>
                        <tr>
                            <td>#<?= $d['DonationID'] ?></td>
                            <td><?= htmlspecialchars($d['DonorName']) ?><br><small><?= htmlspecialchars($d['Phone']) ?></small></td>
                            <td><?= date('M d, Y', strtotime($d['DonationDate'])) ?></td>
                            <td><?= htmlspecialchars($d['Remarks'] ?? 'N/A') ?></td>
                            <td>
                                <span class="badge <?= $d['DonationStatus'] == 'Approved' ? 'badge-approved' : ($d['DonationStatus'] == 'Rejected' ? 'badge-rejected' : 'badge-pending') ?>">
                                    <?= htmlspecialchars($d['DonationStatus']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if($d['DonationStatus'] === 'Pending'): ?>
                                <form method="POST" style="display:flex; gap:5px;">
                                    <input type="hidden" name="donation_id" value="<?= $d['DonationID'] ?>">
                                    <button type="submit" name="action" value="approve" class="btn btn-primary" style="padding:4px 8px; font-size:12px;">Approve</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger" style="padding:4px 8px; font-size:12px;">Reject</button>
                                </form>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
