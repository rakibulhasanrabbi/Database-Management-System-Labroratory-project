<?php
// ============================================================
// admin/inventory.php
// Inventory & Stock Management
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'admin') {
    redirect('/free_medicine/free_medicine/login.php');
}

// Handle Add Medicine
if (isset($_POST['action']) && $_POST['action'] === 'add_medicine') {
    $name = $_POST['medicine_name'];
    $generic = $_POST['generic_name'];
    $cat = $_POST['category_id'];
    
    $stmt = $pdo->prepare("INSERT INTO medicines (MedicineName, GenericName, CategoryID) VALUES (?, ?, ?)");
    $stmt->execute([$name, $generic, $cat]);
    $medId = $pdo->lastInsertId();
    
    $invStmt = $pdo->prepare("INSERT INTO inventory (MedicineID, AvailableQuantity) VALUES (?, 0)");
    $invStmt->execute([$medId]);
    
    redirect('/free_medicine/free_medicine/admin/inventory.php?msg=added');
}

// Handle Update Quantity
if (isset($_POST['action']) && $_POST['action'] === 'update_qty') {
    $invId = $_POST['inventory_id'];
    $qty = $_POST['quantity'];
    
    $stmt = $pdo->prepare("UPDATE inventory SET AvailableQuantity = ? WHERE InventoryID = ?");
    $stmt->execute([$qty, $invId]);
    redirect('/free_medicine/free_medicine/admin/inventory.php?msg=updated');
}

$inventory = $pdo->query("
    SELECT i.InventoryID, i.AvailableQuantity, m.MedicineName, m.GenericName, c.CategoryName
    FROM inventory i
    JOIN medicines m ON i.MedicineID = m.MedicineID
    LEFT JOIN medicinecategories c ON m.CategoryID = c.CategoryID
")->fetchAll();

$categories = $pdo->query("SELECT * FROM medicinecategories")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory — Admin Panel</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar">
    <div class="navbar-brand"><i class="fas fa-shield-alt"></i> Admin Panel</div>
    <div class="navbar-user">
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <aside class="sidebar">
        <div class="sidebar-label">Admin Menu</div>
        <a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="users.php"><i class="fas fa-users"></i> Users & Roles</a>
        <a href="inventory.php" class="active"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="requests.php"><i class="fas fa-hand-holding-medical"></i> Citizen Requests</a>
        <a href="donations.php"><i class="fas fa-box-open"></i> Donations</a>
    </aside>

    <main class="main-content">
        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">Action completed successfully.</div>
        <?php endif; ?>

        <div class="card" style="margin-bottom: 20px;">
            <h2 class="card-title"><i class="fas fa-plus-circle"></i> Add New Medicine to System</h2>
            <form method="POST" style="display:flex; gap:10px; align-items:flex-end;">
                <input type="hidden" name="action" value="add_medicine">
                <div class="form-group" style="margin:0; flex:1;">
                    <label>Medicine Name</label>
                    <input type="text" name="medicine_name" required>
                </div>
                <div class="form-group" style="margin:0; flex:1;">
                    <label>Generic Name</label>
                    <input type="text" name="generic_name">
                </div>
                <div class="form-group" style="margin:0; flex:1;">
                    <label>Category</label>
                    <select name="category_id" required>
                        <?php foreach($categories as $c): ?>
                            <option value="<?= $c['CategoryID'] ?>"><?= htmlspecialchars($c['CategoryName']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width:auto;">Add</button>
            </form>
        </div>

        <div class="card">
            <h2 class="card-title"><i class="fas fa-boxes"></i> Current Stock</h2>
            <table>
                <thead>
                    <tr>
                        <th>Medicine</th>
                        <th>Generic</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($inventory as $i): ?>
                        <tr>
                            <td><?= htmlspecialchars($i['MedicineName']) ?></td>
                            <td><?= htmlspecialchars($i['GenericName']) ?></td>
                            <td><?= htmlspecialchars($i['CategoryName'] ?? 'N/A') ?></td>
                            <td style="font-weight:bold; color: <?= $i['AvailableQuantity'] < 10 ? 'red' : 'green' ?>;">
                                <?= $i['AvailableQuantity'] ?>
                            </td>
                            <td>
                                <form method="POST" style="display:flex; gap:5px;">
                                    <input type="hidden" name="action" value="update_qty">
                                    <input type="hidden" name="inventory_id" value="<?= $i['InventoryID'] ?>">
                                    <input type="number" name="quantity" value="<?= $i['AvailableQuantity'] ?>" style="width:70px; padding:4px;" required>
                                    <button type="submit" class="btn btn-secondary" style="padding:4px 8px; font-size:12px;">Save</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
