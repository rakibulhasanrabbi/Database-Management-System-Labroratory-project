<?php
// ============================================================
// admin/dashboard.php
// Admin Dashboard Overview
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'admin') {
    redirect('/free_medicine/free_medicine/login.php');
}

$adminId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE AdminID = ?");
$stmt->execute([$adminId]);
$admin = $stmt->fetch();
$adminName = $admin['AdminName'] ?? 'Admin';

// Fetch Statistics
$statUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$statDonors = $pdo->query("SELECT COUNT(*) FROM donors")->fetchColumn();
$statRequests = $pdo->query("SELECT COUNT(*) FROM requests WHERE RequestStatus='Pending'")->fetchColumn();
$statDonations = $pdo->query("SELECT COUNT(*) FROM donations WHERE DonationStatus='Pending'")->fetchColumn();

// Fetch Expiry Alerts (Medicines expiring in next 30 days)
$expiryStmt = $pdo->query("
    SELECT m.MedicineName, di.ExpiryDate, di.Quantity 
    FROM donationitems di 
    JOIN medicines m ON di.MedicineID = m.MedicineID 
    WHERE di.ExpiryDate <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
    AND di.ExpiryDate >= CURDATE()
");
$expiringItems = $expiryStmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard — Free Medicine</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; padding: 20px; border-radius: 12px; box-shadow: var(--shadow); text-align: center; }
        .stat-card h3 { font-size: 32px; color: var(--primary); margin-bottom: 8px; }
        .stat-card p { color: var(--gray-500); font-size: 14px; font-weight: 600; text-transform: uppercase; }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="navbar-brand"><i class="fas fa-shield-alt"></i> Admin Panel</div>
    <div class="navbar-user">
        <span><i class="fas fa-user-shield"></i> <?= htmlspecialchars($adminName) ?></span>
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-label">Admin Menu</div>
        <a href="dashboard.php" class="active"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="users.php"><i class="fas fa-users"></i> Users & Roles</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="requests.php"><i class="fas fa-hand-holding-medical"></i> Citizen Requests</a>
        <a href="donations.php"><i class="fas fa-box-open"></i> Donations</a>
    </aside>

    <main class="main-content">
        <div class="dashboard-grid">
            <div class="stat-card"><h3><?= $statUsers ?></h3><p>Citizens</p></div>
            <div class="stat-card"><h3><?= $statDonors ?></h3><p>Donors</p></div>
            <div class="stat-card"><h3><?= $statRequests ?></h3><p>Pending Requests</p></div>
            <div class="stat-card"><h3><?= $statDonations ?></h3><p>Pending Donations</p></div>
        </div>

        <div class="card">
            <h2 class="card-title"><i class="fas fa-exclamation-triangle" style="color:var(--warning);"></i> Expiry Alerts (Next 30 Days)</h2>
            <?php if (count($expiringItems) > 0): ?>
                <table>
                    <thead><tr><th>Medicine</th><th>Expiry Date</th><th>Quantity</th></tr></thead>
                    <tbody>
                        <?php foreach ($expiringItems as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['MedicineName']) ?></td>
                                <td style="color:var(--danger); font-weight:bold;"><?= htmlspecialchars($item['ExpiryDate']) ?></td>
                                <td><?= htmlspecialchars($item['Quantity']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No medicines expiring soon.</p>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
