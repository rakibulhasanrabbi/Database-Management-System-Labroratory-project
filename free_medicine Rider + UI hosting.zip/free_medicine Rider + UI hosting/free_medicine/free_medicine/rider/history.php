<?php
// ============================================================
// rider/history.php
// Rider Delivery History
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'rider') {
    redirect('/free_medicine/free_medicine/login.php');
}

$riderId = $_SESSION['user_id'];

// Fetch Rider Info
$stmt = $pdo->prepare("SELECT * FROM deliveryriders WHERE RiderID = ?");
$stmt->execute([$riderId]);
$rider = $stmt->fetch();
$riderName = $rider['RiderName'] ?? 'Rider';

// Fetch past deliveries (Delivered)
$histStmt = $pdo->prepare("SELECT d.*, r.UrgencyLevel, r.RequestDate 
                          FROM distribution d 
                          LEFT JOIN requests r ON d.RequestID = r.RequestID 
                          WHERE d.RiderID = ? AND d.DeliveryStatus = 'Delivered'
                          ORDER BY d.DistributionDate DESC");
$histStmt->execute([$riderId]);
$history = $histStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery History — Free Medicine Distribution</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
    <div class="navbar-brand">
        <i class="fas fa-pills"></i>
        <span>Free Medicine Distribution</span>
    </div>
    <div class="navbar-user">
        <span><i class="fas fa-motorcycle"></i> <?= htmlspecialchars($riderName) ?></span>
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-label">Rider Menu</div>
        <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="history.php" class="active"><i class="fas fa-history"></i> Delivery History</a>
        <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="card">
            <h2 class="card-title"><i class="fas fa-history"></i> My Delivery History</h2>
            
            <?php if (count($history) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Receiver Name</th>
                            <th>Phone</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $h): ?>
                            <tr>
                                <td>#<?= $h['DistributionID'] ?></td>
                                <td><?= htmlspecialchars($h['ReceiverName'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($h['ReceiverPhone'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($h['DistributionDate'] ?? 'N/A') ?></td>
                                <td>
                                    <span class="badge badge-approved">Delivered</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: var(--gray-500); font-size: 14px;">You haven't completed any deliveries yet.</p>
            <?php endif; ?>
        </div>
    </main>
</div>

</body>
</html>
