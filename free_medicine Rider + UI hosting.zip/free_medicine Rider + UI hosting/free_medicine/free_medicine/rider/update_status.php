<?php
// ============================================================
// rider/update_status.php
// Handle Delivery Status Updates
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'rider') {
    redirect('/free_medicine/free_medicine/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $distributionId = $_POST['distribution_id'] ?? null;
    $status = $_POST['status'] ?? null;
    $riderId = $_SESSION['user_id'];

    if ($distributionId && $status) {
        $stmt = $pdo->prepare("UPDATE distribution SET DeliveryStatus = ? WHERE DistributionID = ? AND RiderID = ?");
        $stmt->execute([$status, $distributionId, $riderId]);
        
        redirect('/free_medicine/free_medicine/rider/dashboard.php?msg=status_updated');
    }
}

redirect('/free_medicine/free_medicine/rider/dashboard.php');
?>
