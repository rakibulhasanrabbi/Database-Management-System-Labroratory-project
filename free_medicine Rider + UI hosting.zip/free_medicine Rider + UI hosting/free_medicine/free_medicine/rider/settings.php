<?php
// ============================================================
// rider/settings.php
// Rider Settings & Profile
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'rider') {
    redirect('/free_medicine/free_medicine/login.php');
}

$riderId = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (!empty($name) && !empty($phone)) {
        $updStmt = $pdo->prepare("UPDATE deliveryriders SET RiderName = ?, Phone = ?, Address = ? WHERE RiderID = ?");
        if ($updStmt->execute([$name, $phone, $address, $riderId])) {
            $success = "Profile updated successfully.";
        } else {
            $error = "Failed to update profile.";
        }
    } else {
        $error = "Name and Phone are required.";
    }
}

// Fetch Rider Info
$stmt = $pdo->prepare("SELECT * FROM deliveryriders WHERE RiderID = ?");
$stmt->execute([$riderId]);
$rider = $stmt->fetch();
$riderName = $rider['RiderName'] ?? '';
$riderPhone = $rider['Phone'] ?? '';
$riderAddress = $rider['Address'] ?? '';
$riderEmail = $rider['Email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings — Free Medicine Distribution</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .settings-form { max-width: 600px; }
        .form-group { margin-bottom: 20px; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
    <div class="navbar-brand">
        <i class="fas fa-pills"></i>
        <span>Free Medicine Distribution</span>
    </div>
    <div class="navbar-user">
        <span><i class="fas fa-motorcycle"></i> <?= htmlspecialchars($riderName) ?></span>
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-label">Rider Menu</div>
        <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="history.php"><i class="fas fa-history"></i> Delivery History</a>
        <a href="settings.php" class="active"><i class="fas fa-cog"></i> Settings</a>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="card settings-form">
            <h2 class="card-title"><i class="fas fa-user-edit"></i> Profile Settings</h2>
            
            <?php if ($success): ?>
                <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="settings.php">
                <div class="form-group">
                    <label>Email Address (Read Only)</label>
                    <input type="email" value="<?= htmlspecialchars($riderEmail) ?>" disabled style="background:#e9ecef;">
                </div>
                
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($riderName) ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?= htmlspecialchars($riderPhone) ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" rows="3"><?= htmlspecialchars($riderAddress) ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Update Profile</button>
            </form>
        </div>
    </main>
</div>

</body>
</html>
