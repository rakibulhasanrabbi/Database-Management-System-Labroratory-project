<?php
// ============================================================
// rider/dashboard.php
// Rider Dashboard
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'rider') {
    redirect('/free_medicine/free_medicine/login.php');
}

$riderId = $_SESSION['user_id'];

// Fetch Rider Info
$stmt = $pdo->prepare("SELECT * FROM deliveryriders WHERE RiderID = ?");
$stmt->execute([$riderId]);
$rider = $stmt->fetch();
$riderName = $rider['RiderName'] ?? 'Rider';

// Fetch Assigned Deliveries
$delStmt = $pdo->prepare("SELECT d.*, r.UrgencyLevel, r.RequestDate 
                          FROM distribution d 
                          LEFT JOIN requests r ON d.RequestID = r.RequestID 
                          WHERE d.RiderID = ? 
                          ORDER BY d.DistributionDate DESC");
$delStmt->execute([$riderId]);
$deliveries = $delStmt->fetchAll();

// Fetch Pending/Unassigned Deliveries (Available to pick up)
$availStmt = $pdo->prepare("SELECT d.*, r.UrgencyLevel 
                            FROM distribution d 
                            LEFT JOIN requests r ON d.RequestID = r.RequestID 
                            WHERE d.RiderID IS NULL AND d.DistributionMethod = 'Delivery'
                            ORDER BY d.DistributionDate DESC");
$availStmt->execute();
$availableDeliveries = $availStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Dashboard — Free Medicine Distribution</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
    <div class="navbar-brand">
        <i class="fas fa-pills"></i>
        <span>Free Medicine Distribution</span>
    </div>
    <div class="navbar-user">
        <span><i class="fas fa-motorcycle"></i> <?= htmlspecialchars($riderName) ?></span>
        <a href="/free_medicine/free_medicine/logout.php" class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">Logout</a>
    </div>
</nav>

<div class="page-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-label">Rider Menu</div>
        <a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
        <a href="history.php"><i class="fas fa-history"></i> Delivery History</a>
        <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'status_updated'): ?>
            <div class="alert alert-success">✅ Delivery status updated successfully.</div>
        <?php endif; ?>
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'job_accepted'): ?>
            <div class="alert alert-success">✅ You have successfully accepted the delivery job.</div>
        <?php endif; ?>

        <div class="card">
            <h2 class="card-title"><i class="fas fa-motorcycle"></i> My Assigned Deliveries</h2>
            
            <?php if (count($deliveries) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Receiver Name</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($deliveries as $d): ?>
                            <tr>
                                <td>#<?= $d['DistributionID'] ?></td>
                                <td><?= htmlspecialchars($d['ReceiverName'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($d['ReceiverPhone'] ?? 'N/A') ?></td>
                                <td>
                                    <?php
                                        $badgeClass = 'badge-pending';
                                        if ($d['DeliveryStatus'] === 'Delivered') $badgeClass = 'badge-approved';
                                        elseif ($d['DeliveryStatus'] === 'In Transit') $badgeClass = 'badge-info';
                                    ?>
                                    <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($d['DeliveryStatus'] ?? 'Pending') ?></span>
                                </td>
                                <td>
                                    <form action="update_status.php" method="POST" style="display:flex; gap:8px;">
                                        <input type="hidden" name="distribution_id" value="<?= $d['DistributionID'] ?>">
                                        <select name="status" style="padding:4px; font-size:12px; border-radius:4px; border:1px solid #ccc;">
                                            <option value="Pending" <?= $d['DeliveryStatus'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                            <option value="In Transit" <?= $d['DeliveryStatus'] == 'In Transit' ? 'selected' : '' ?>>In Transit</option>
                                            <option value="Delivered" <?= $d['DeliveryStatus'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                        </select>
                                        <button type="submit" class="btn btn-primary" style="padding:4px 8px; font-size:12px;">Update</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: var(--gray-500); font-size: 14px;">You currently have no active deliveries assigned to you.</p>
            <?php endif; ?>
        </div>

        <div class="card">
            <h2 class="card-title"><i class="fas fa-box-open"></i> Available Deliveries</h2>
            
            <?php if (count($availableDeliveries) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Receiver Name</th>
                            <th>Phone</th>
                            <th>Urgency</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($availableDeliveries as $a): ?>
                            <tr>
                                <td>#<?= $a['DistributionID'] ?></td>
                                <td><?= htmlspecialchars($a['ReceiverName'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($a['ReceiverPhone'] ?? 'N/A') ?></td>
                                <td>
                                    <?php
                                        $uBadge = 'badge-pending';
                                        if ($a['UrgencyLevel'] === 'High') $uBadge = 'badge-rejected';
                                    ?>
                                    <span class="badge <?= $uBadge ?>"><?= htmlspecialchars($a['UrgencyLevel'] ?? 'Normal') ?></span>
                                </td>
                                <td>
                                    <form action="accept_delivery.php" method="POST">
                                        <input type="hidden" name="distribution_id" value="<?= $a['DistributionID'] ?>">
                                        <button type="submit" class="btn btn-secondary" style="padding:6px 12px; font-size:12px;"><i class="fas fa-check"></i> Accept Job</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: var(--gray-500); font-size: 14px;">There are no open delivery jobs available right now.</p>
            <?php endif; ?>
        </div>
        
    </main>
</div>

</body>
</html>
