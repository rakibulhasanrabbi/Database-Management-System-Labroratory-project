<?php
// ============================================================
// rider/accept_delivery.php
// Handle accepting available deliveries
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'rider') {
    redirect('/free_medicine/free_medicine/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $distributionId = $_POST['distribution_id'] ?? null;
    $riderId = $_SESSION['user_id'];

    if ($distributionId) {
        $stmt = $pdo->prepare("UPDATE distribution SET RiderID = ?, DeliveryStatus = 'In Transit' WHERE DistributionID = ? AND RiderID IS NULL");
        $stmt->execute([$riderId, $distributionId]);
        
        redirect('/free_medicine/free_medicine/rider/dashboard.php?msg=job_accepted');
    }
}

redirect('/free_medicine/free_medicine/rider/dashboard.php');
?>
