UPDATE admins SET Password = '$2y$10$IryDl3.aZ7.JlFgm3vWIm.pDMo0ydGBrtZ1R5vfe/VAKWNS1t0iwa' WHERE Email = 'admin@medicine.com';
