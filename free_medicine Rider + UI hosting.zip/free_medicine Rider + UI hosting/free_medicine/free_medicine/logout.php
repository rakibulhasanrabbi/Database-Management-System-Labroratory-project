<?php
require_once __DIR__ . '/includes/middleware.php';

session_unset();
session_destroy();

header("Location: /free_medicine/free_medicine/login.php?msg=logged_out");
exit;
?>
