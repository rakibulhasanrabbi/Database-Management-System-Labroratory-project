<?php
function redirect($url) {
    header("Location: " . $url);
    exit;
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function loginUser($pdo, $email, $password, $role) {
    $table = 'users';
    if ($role === 'admin') $table = 'admins';
    elseif ($role === 'donor') $table = 'donors';
    elseif ($role === 'rider') $table = 'deliveryriders';

    $stmt = $pdo->prepare("SELECT * FROM $table WHERE Email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Compare password (use password_verify if hashed, or plain text depending on DB data)
        $dbPass = $user['Password'] ?? $user['password'] ?? '';
        
        if (password_verify($password, $dbPass) || $password === $dbPass) {
            $userId = $user['UserID'] ?? $user['DonorID'] ?? $user['RiderID'] ?? $user['AdminID'] ?? $user['ID'] ?? $user['id'] ?? null;
            $_SESSION['user_id'] = $userId;
            $_SESSION['role'] = $role;
            return true;
        } else {
            return false;
        }
    }
    return 'not_found';
}

function redirectToDashboard($role) {
    switch ($role) {
        case 'admin':   redirect('/free_medicine/free_medicine/admin/dashboard.php');   break;
        case 'donor':   redirect('/free_medicine/free_medicine/donor/dashboard.php');   break;
        case 'user':    redirect('/free_medicine/free_medicine/citizen/dashboard.php'); break;
        case 'rider':   redirect('/free_medicine/free_medicine/rider/dashboard.php');   break;
        default:        redirect('/free_medicine/free_medicine/login.php');             break;
    }
}
?>
