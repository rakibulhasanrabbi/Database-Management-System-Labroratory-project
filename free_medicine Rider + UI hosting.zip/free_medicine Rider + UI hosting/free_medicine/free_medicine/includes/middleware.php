<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

function redirectIfLoggedIn() {
    if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
        redirectToDashboard($_SESSION['role']);
    }
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        redirect('/free_medicine/free_medicine/login.php');
    }
}
?>
