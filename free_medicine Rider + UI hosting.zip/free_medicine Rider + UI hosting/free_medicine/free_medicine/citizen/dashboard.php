<?php
// ============================================================
// citizen/dashboard.php
// Citizen Dashboard
// ============================================================
require_once __DIR__ . '/../includes/middleware.php';
requireLogin();

if ($_SESSION['role'] !== 'user') {
    header("Location: /free_medicine/free_medicine/login.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE UserID = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
$name = $user['FullName'] ?? 'Citizen';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Citizen Dashboard</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f7f6; margin: 0; }
        .topbar { background-color: #2c3e50; color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .topbar h2 { margin: 0; font-size: 20px; }
        .container { padding: 40px 30px; max-width: 1200px; margin: auto; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 20px; }
    </style>
</head>
<body>
<div class="topbar">
    <h2>🏠 Citizen Dashboard</h2>
    <a href="/free_medicine/free_medicine/logout.php" style="color:white; font-size:13px; text-decoration:none; background:#e74c3c; padding:8px 15px; border-radius:4px;">Logout →</a>
</div>
<div class="container">
    <div class="card">
        <h3>Welcome, <?= htmlspecialchars($name) ?>!</h3>
        <p>Request medicines and track your orders here.</p>
    </div>
</div>
</body>
</html>
