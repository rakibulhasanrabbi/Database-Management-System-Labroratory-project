<?php
// ============================================================
// register.php
// Registration Page — Free Medicine Distribution System
// ============================================================

require_once __DIR__ . '/includes/middleware.php';

// If already logged in, go to dashboard
redirectIfLoggedIn();

$error   = '';
$success = '';

// ---- Handle form submission ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role     = trim($_POST['role']     ?? '');
    $name     = trim($_POST['name']     ?? '');
    $phone    = trim($_POST['phone']    ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');
    $address  = trim($_POST['address']  ?? '');

    // Basic validation
    if (empty($role) || empty($name) || empty($phone) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            if ($role === 'donor') {
                $stmt = $pdo->prepare("INSERT INTO donors (DonorName, Phone, Email, Password, Address) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $phone, $email, $hashedPassword, $address]);
            } elseif ($role === 'rider') {
                $stmt = $pdo->prepare("INSERT INTO deliveryriders (RiderName, Phone, Email, Password, Address) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $phone, $email, $hashedPassword, $address]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO users (FullName, Phone, Email, Password, Address) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $phone, $email, $hashedPassword, $address]);
            }
            $success = 'Registration successful! You can now login.';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Integrity constraint violation (duplicate email)
                $error = 'This email is already registered. Please login instead.';
            } else {
                $error = 'An error occurred during registration. Please try again.';
            }
        }
    }
    
    $selectedRole = htmlspecialchars($role);
} else {
    $selectedRole = 'user';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — Free Medicine Distribution</title>
    <link rel="stylesheet" href="/free_medicine/free_medicine/assets/css/style.css">
    <style>
        .input-icon-wrapper { position: relative; margin-bottom: 15px; }
        .input-icon-wrapper span.icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); font-size: 16px; color: #adb5bd; }
        .input-icon-wrapper input, .input-icon-wrapper textarea { padding-left: 38px; width: 100%; box-sizing: border-box; }
        .input-icon-wrapper textarea { padding-top: 10px; }
        .toggle-password { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 16px; color: #adb5bd; user-select: none; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; color: #333; }
    </style>
</head>
<body>
<div class="auth-wrapper" style="padding: 40px 0;">
    <div class="auth-card" style="max-width: 500px;">

        <!-- Header -->
        <div class="auth-header">
            <div class="logo">💊</div>
            <h1>Create an Account</h1>
            <p>Join the Free Medicine Distribution System</p>
        </div>

        <!-- Body -->
        <div class="auth-body">
            <?php if ($success): ?>
                <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
                <div style="text-align: center; margin-top: 20px;">
                    <a href="/free_medicine/free_medicine/login.php" class="btn btn-primary" style="display: inline-block;">Go to Login →</a>
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="alert alert-error">⚠️ <?= $error ?></div>
                <?php endif; ?>

                <p style="font-size:13px; color:#6c757d; margin-bottom:15px;">Select your account type:</p>
                
                <!-- Role Tabs -->
                <div class="role-tabs">
                    <button class="role-tab <?= $selectedRole === 'user'  ? 'active' : '' ?>"
                            onclick="setRole('user')"  type="button">🏠 Citizen</button>
                    <button class="role-tab <?= $selectedRole === 'donor' ? 'active' : '' ?>"
                            onclick="setRole('donor')" type="button">🤝 Donor</button>
                    <button class="role-tab <?= $selectedRole === 'rider' ? 'active' : '' ?>"
                            onclick="setRole('rider')" type="button">🚴 Rider</button>
                </div>

                <!-- Register Form -->
                <form method="POST" action="register.php" id="registerForm">
                    <input type="hidden" name="role" id="roleInput" value="<?= $selectedRole ?>">

                    <div class="form-group">
                        <label for="name">Full Name *</label>
                        <div class="input-icon-wrapper">
                            <span class="icon">👤</span>
                            <input type="text" name="name" id="name" placeholder="Enter your full name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <div class="input-icon-wrapper">
                            <span class="icon">📞</span>
                            <input type="text" name="phone" id="phone" placeholder="Enter your phone number" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <div class="input-icon-wrapper">
                            <span class="icon">📧</span>
                            <input type="email" name="email" id="email" placeholder="Enter your email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password">Password *</label>
                        <div class="input-icon-wrapper">
                            <span class="icon">🔒</span>
                            <input type="password" name="password" id="password" placeholder="Create a password" required>
                            <span class="toggle-password" onclick="togglePassword()">👁️</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <div class="input-icon-wrapper">
                            <span class="icon">📍</span>
                            <textarea name="address" id="address" rows="2" placeholder="Enter your full address (optional)"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 10px; width: 100%;">
                        Register Account →
                    </button>
                </form>

                <div class="auth-footer" style="margin-top: 20px;">
                    Already have an account? 
                    <a href="/free_medicine/free_medicine/login.php" style="font-weight:700;">→ Click here to Login</a>
                </div>
            <?php endif; ?>

        </div><!-- /auth-body -->
    </div><!-- /auth-card -->
</div><!-- /auth-wrapper -->

<script>
    function setRole(role) {
        document.getElementById('roleInput').value = role;
        document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
        event.target.classList.add('active');
    }

    function togglePassword() {
        const pwd = document.getElementById('password');
        pwd.type = pwd.type === 'password' ? 'text' : 'password';
    }
</script>
</body>
</html>
