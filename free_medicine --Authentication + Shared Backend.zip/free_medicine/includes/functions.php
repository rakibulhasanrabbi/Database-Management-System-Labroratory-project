<?php
// ============================================================
// includes/functions.php
// Shared Helper Functions — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
// ============================================================

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ------------------------------------------------------------
// INPUT SANITIZATION
// ------------------------------------------------------------

/**
 * Clean user input to prevent XSS attacks
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// ------------------------------------------------------------
// PASSWORD FUNCTIONS
// ------------------------------------------------------------

/**
 * Hash a password securely using bcrypt
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
}

/**
 * Verify a password against a hash
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// ------------------------------------------------------------
// REDIRECT & NAVIGATION
// ------------------------------------------------------------

/**
 * Redirect to a given URL and stop execution
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * Redirect user to their role-specific dashboard
 */
function redirectToDashboard($role) {
    switch ($role) {
        case 'admin':   redirect('/free_medicine/admin/dashboard.php');   break;
        case 'donor':   redirect('/free_medicine/donor/dashboard.php');   break;
        case 'user':    redirect('/free_medicine/citizen/dashboard.php'); break;
        case 'rider':   redirect('/free_medicine/rider/dashboard.php');   break;
        default:        redirect('/free_medicine/login.php');             break;
    }
}

// ------------------------------------------------------------
// FLASH MESSAGES (success / error / info messages)
// ------------------------------------------------------------

/**
 * Store a flash message in session (shown once, then disappears)
 */
function setFlashMessage($type, $message) {
    $_SESSION['flash'] = [
        'type'    => $type,     // 'success', 'error', 'info', 'warning'
        'message' => $message
    ];
}

/**
 * Get and clear the flash message from session
 */
function getFlashMessage() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Display flash message as HTML (call in page body)
 */
function showFlashMessage() {
    $flash = getFlashMessage();
    if (!$flash) return;

    $colors = [
        'success' => '#d4edda',
        'error'   => '#f8d7da',
        'info'    => '#d1ecf1',
        'warning' => '#fff3cd',
    ];
    $borders = [
        'success' => '#28a745',
        'error'   => '#dc3545',
        'info'    => '#17a2b8',
        'warning' => '#ffc107',
    ];

    $bg  = $colors[$flash['type']]  ?? '#fff3cd';
    $bdr = $borders[$flash['type']] ?? '#ffc107';

    echo '<div style="background:' . $bg . '; border-left:4px solid ' . $bdr . ';
                padding:12px 18px; margin:16px 0; border-radius:4px; font-size:14px;">
            ' . htmlspecialchars($flash['message']) . '
          </div>';
}

// ------------------------------------------------------------
// VALIDATION
// ------------------------------------------------------------

/**
 * Check if an email is valid
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Check if a phone number is valid (10-15 digits)
 */
function isValidPhone($phone) {
    return preg_match('/^[0-9]{10,15}$/', $phone);
}

/**
 * Check if a string is not empty
 */
function isNotEmpty($value) {
    return trim($value) !== '';
}

// ------------------------------------------------------------
// NOTIFICATION FUNCTIONS
// ------------------------------------------------------------

/**
 * Create a new notification for a user
 *
 * @param PDO    $pdo
 * @param string $userType  'user' | 'donor' | 'admin' | 'rider'
 * @param int    $userID
 * @param string $message
 */
function addNotification($pdo, $userType, $userID, $message) {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO Notifications (UserType, UserID, Message, IsRead, CreatedAt)
             VALUES (?, ?, ?, 0, NOW())"
        );
        $stmt->execute([$userType, $userID, $message]);
    } catch (PDOException $e) {
        // Silent fail — notifications are non-critical
    }
}

/**
 * Get recent notifications for a user (last 15)
 */
function getNotifications($pdo, $userType, $userID) {
    try {
        $stmt = $pdo->prepare(
            "SELECT * FROM Notifications
             WHERE UserType = ? AND UserID = ?
             ORDER BY CreatedAt DESC LIMIT 15"
        );
        $stmt->execute([$userType, $userID]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Get unread notification count for a user
 */
function getUnreadCount($pdo, $userType, $userID) {
    try {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM Notifications
             WHERE UserType = ? AND UserID = ? AND IsRead = 0"
        );
        $stmt->execute([$userType, $userID]);
        return (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Mark all notifications as read for a user
 */
function markAllRead($pdo, $userType, $userID) {
    try {
        $stmt = $pdo->prepare(
            "UPDATE Notifications SET IsRead = 1
             WHERE UserType = ? AND UserID = ?"
        );
        $stmt->execute([$userType, $userID]);
    } catch (PDOException $e) {
        // Silent fail
    }
}

// ------------------------------------------------------------
// UTILITY
// ------------------------------------------------------------

/**
 * Format a datetime string nicely
 */
function formatDate($datetime) {
    if (!$datetime) return 'N/A';
    return date('d M Y, h:i A', strtotime($datetime));
}

/**
 * Truncate a string to a given length
 */
function truncate($text, $length = 50) {
    if (strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}
?>
