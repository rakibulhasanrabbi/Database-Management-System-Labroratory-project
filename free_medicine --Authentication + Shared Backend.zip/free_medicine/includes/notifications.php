<?php
// ============================================================
// includes/notifications.php
// Notification API Endpoint — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
//
// This file handles AJAX requests for the notification bell.
// Call it via fetch('/includes/notifications.php?action=...')
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

// Must be logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$user     = getCurrentUser();
$userType = $user['role'];
$userID   = $user['id'];
$action   = $_GET['action'] ?? 'get';

header('Content-Type: application/json');

switch ($action) {

    // ---------------------------------------------------------
    // GET: Return last 15 notifications + unread count
    // ---------------------------------------------------------
    case 'get':
        $notifications = getNotifications($pdo, $userType, $userID);
        $unreadCount   = getUnreadCount($pdo, $userType, $userID);

        // Format timestamps nicely
        foreach ($notifications as &$n) {
            $n['CreatedAt'] = formatDate($n['CreatedAt']);
        }

        echo json_encode([
            'success'      => true,
            'unread_count' => $unreadCount,
            'notifications' => $notifications
        ]);
        break;

    // ---------------------------------------------------------
    // MARK_READ: Mark all notifications as read
    // ---------------------------------------------------------
    case 'mark_read':
        markAllRead($pdo, $userType, $userID);
        echo json_encode(['success' => true, 'message' => 'All marked as read']);
        break;

    // ---------------------------------------------------------
    // COUNT: Return just the unread count (for badge)
    // ---------------------------------------------------------
    case 'count':
        $count = getUnreadCount($pdo, $userType, $userID);
        echo json_encode(['success' => true, 'unread_count' => $count]);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?>
