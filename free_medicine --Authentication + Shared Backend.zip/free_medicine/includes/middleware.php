<?php
// ============================================================
// includes/middleware.php
// Route Protection / Access Control — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
//
// HOW TO USE:
//   At the TOP of any protected page, add:
//   require_once '../includes/middleware.php';
//   requireAdmin();     // only admins can access
//   requireDonor();     // only donors can access
//   requireUser();      // only citizens/users can access
//   requireRider();     // only riders can access
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

// ============================================================
// CORE: Require login (any role)
// ============================================================

/**
 * Redirect to login if the visitor is not logged in
 */
function requireLogin() {
    if (!isLoggedIn()) {
        setFlashMessage('error', 'Please login to access this page.');
        redirect('/free_medicine/login.php');
    }
}

// ============================================================
// ROLE-SPECIFIC GUARDS
// ============================================================

/**
 * General role checker — redirects if user doesn't have the required role
 *
 * @param string $requiredRole  'user' | 'donor' | 'admin' | 'rider'
 */
function requireRole($requiredRole) {
    requireLogin();
    if (getCurrentRole() !== $requiredRole) {
        setFlashMessage('error', 'Access denied. You do not have permission to view this page.');
        redirect('/free_medicine/login.php');
    }
}

/**
 * Only Admins can access
 */
function requireAdmin() {
    requireRole('admin');
}

/**
 * Only Donors can access
 */
function requireDonor() {
    requireRole('donor');
}

/**
 * Only Citizens (Users) can access
 */
function requireUser() {
    requireRole('user');
}

/**
 * Only Delivery Riders can access
 */
function requireRider() {
    requireRole('rider');
}

// ============================================================
// REDIRECT IF ALREADY LOGGED IN
// ============================================================

/**
 * If a logged-in user visits login/register pages,
 * send them to their dashboard automatically
 */
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        redirectToDashboard(getCurrentRole());
    }
}
?>
