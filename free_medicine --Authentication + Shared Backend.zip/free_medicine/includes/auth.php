<?php
// ============================================================
// includes/auth.php
// Authentication Logic — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

// ============================================================
// LOGIN
// ============================================================

/**
 * Attempt to log in a user by email, password, and role.
 *
 * @param PDO    $pdo
 * @param string $email
 * @param string $password
 * @param string $role      'user' | 'donor' | 'admin' | 'rider'
 *
 * @return true|false|'inactive'|'not_found'
 */
function loginUser($pdo, $email, $password, $role) {
    $email = strtolower(trim($email));

    // Choose the right table and columns based on role
    switch ($role) {
        case 'user':
            $sql  = "SELECT UserID AS id, FullName AS name, Email, Password, Status FROM Users WHERE Email = ?";
            break;
        case 'donor':
            $sql  = "SELECT DonorID AS id, DonorName AS name, Email, Password, Status FROM Donors WHERE Email = ?";
            break;
        case 'admin':
            $sql  = "SELECT AdminID AS id, AdminName AS name, Email, Password, Status FROM Admins WHERE Email = ?";
            break;
        case 'rider':
            $sql  = "SELECT RiderID AS id, RiderName AS name, Email, Password, Status FROM DeliveryRiders WHERE Email = ?";
            break;
        default:
            return false;
    }

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        return false;
    }

    // Email not found
    if (!$user) return 'not_found';

    // Account is suspended / inactive
    if ($user['Status'] !== 'active') return 'inactive';

    // Wrong password
    if (!verifyPassword($password, $user['Password'])) return false;

    // ✅ Successful login — store session
    $_SESSION['logged_in']  = true;
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $user['name'];
    $_SESSION['user_email'] = $user['Email'];
    $_SESSION['user_role']  = $role;

    return true;
}

// ============================================================
// LOGOUT
// ============================================================

/**
 * Destroy the session and redirect to login page
 */
function logoutUser() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    session_unset();
    session_destroy();
    header("Location: /login.php");
    exit();
}

// ============================================================
// SESSION CHECKS
// ============================================================

/**
 * Returns true if the user is currently logged in
 */
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

/**
 * Get the currently logged-in user's info as an array
 * Returns null if not logged in
 */
function getCurrentUser() {
    if (!isLoggedIn()) return null;
    return [
        'id'    => $_SESSION['user_id'],
        'name'  => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role'  => $_SESSION['user_role'],
    ];
}

/**
 * Get the role of the currently logged-in user
 */
function getCurrentRole() {
    return $_SESSION['user_role'] ?? null;
}

/**
 * Get only the ID of the current user
 */
function getCurrentUserID() {
    return $_SESSION['user_id'] ?? null;
}

// ============================================================
// REGISTRATION
// ============================================================

/**
 * Register a new citizen/user
 *
 * @param PDO   $pdo
 * @param array $data   Keys: name, phone, email, password, address
 * @return int|false    New UserID or false on failure
 */
function registerUser($pdo, $data) {
    // Check if email already exists
    if (emailExists($pdo, $data['email'], 'user')) {
        return 'email_exists';
    }

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO Users (FullName, Phone, Email, Password, Address, CreatedAt, Status)
             VALUES (?, ?, ?, ?, ?, NOW(), 'active')"
        );
        $stmt->execute([
            sanitizeInput($data['name']),
            sanitizeInput($data['phone']),
            strtolower(trim($data['email'])),
            hashPassword($data['password']),
            sanitizeInput($data['address'] ?? ''),
        ]);
        return (int) $pdo->lastInsertId();
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Register a new donor
 *
 * @param PDO   $pdo
 * @param array $data   Keys: name, phone, email, password, address, donor_type
 * @return int|false    New DonorID or false on failure
 */
function registerDonor($pdo, $data) {
    // Check if email already exists
    if (emailExists($pdo, $data['email'], 'donor')) {
        return 'email_exists';
    }

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO Donors (DonorName, Phone, Email, Password, Address, DonorType, CreatedAt, Status)
             VALUES (?, ?, ?, ?, ?, ?, NOW(), 'active')"
        );
        $stmt->execute([
            sanitizeInput($data['name']),
            sanitizeInput($data['phone']),
            strtolower(trim($data['email'])),
            hashPassword($data['password']),
            sanitizeInput($data['address'] ?? ''),
            sanitizeInput($data['donor_type'] ?? 'Individual'),
        ]);
        return (int) $pdo->lastInsertId();
    } catch (PDOException $e) {
        return false;
    }
}

// ============================================================
// HELPERS
// ============================================================

/**
 * Check if an email already exists in the given role's table
 */
function emailExists($pdo, $email, $role) {
    $email = strtolower(trim($email));
    switch ($role) {
        case 'user':    $table = 'Users';           $col = 'Email'; break;
        case 'donor':   $table = 'Donors';          $col = 'Email'; break;
        case 'admin':   $table = 'Admins';          $col = 'Email'; break;
        case 'rider':   $table = 'DeliveryRiders';  $col = 'Email'; break;
        default:        return false;
    }
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE $col = ?");
        $stmt->execute([$email]);
        return (int) $stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        return false;
    }
}
?>
