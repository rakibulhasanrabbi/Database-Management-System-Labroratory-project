<?php
// ============================================================
// logout.php
// Logout Handler — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
//
// HOW TO USE (from any page):
//   <a href="/free_medicine/logout.php">Logout</a>
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Destroy session completely
session_unset();
session_destroy();

// Redirect to login with a success message
// (using query param since session is destroyed)
header("Location: /free_medicine/login.php?msg=logged_out");
exit();
?>
