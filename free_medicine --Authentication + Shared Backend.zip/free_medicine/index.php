<?php
// ============================================================
// login.php
// Login Page — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
// ============================================================

require_once __DIR__ . '/includes/middleware.php';

// If already logged in, go to dashboard
redirectIfLoggedIn();

$error   = '';
$success = '';

// Show message if redirected from logout
if (isset($_GET['msg']) && $_GET['msg'] === 'logged_out') {
    $success = 'You have been logged out successfully.';
}

// ---- Handle form submission ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');
    $role     = trim($_POST['role']     ?? '');

    // Basic validation
    if (empty($email) || empty($password) || empty($role)) {
        $error = 'Please fill in all fields and select your role.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Attempt login
        $result = loginUser($pdo, $email, $password, $role);

        if ($result === true) {
            // Success → go to dashboard
            redirectToDashboard($role);
        } elseif ($result === 'inactive') {
            $error = 'Your account is inactive. Please contact the admin.';
        } elseif ($result === 'not_found') {
            $error = 'No account found with this email for the selected role.';
        } else {
            $error = 'Incorrect password. Please try again.';
        }
    }

    // Keep selected role active on error
    $selectedRole = htmlspecialchars($role);
} else {
    $selectedRole = 'user';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Free Medicine Distribution</title>
    <link rel="stylesheet" href="/free_medicine/assets/css/style.css">
    <style>
        .input-icon-wrapper {
            position: relative;
        }
        .input-icon-wrapper span {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 16px;
            color: #adb5bd;
        }
        .input-icon-wrapper input {
            padding-left: 38px;
        }
        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 16px;
            color: #adb5bd;
            user-select: none;
        }
    </style>
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-card">

        <!-- Header -->
        <div class="auth-header">
            <div class="logo">💊</div>
            <h1>Free Medicine Distribution</h1>
            <p>Management System</p>
        </div>

        <!-- Body -->
        <div class="auth-body">
            <h2 style="font-size:18px; font-weight:700; margin-bottom:6px; color:#333;">Welcome Back!</h2>
            <p style="font-size:13px; color:#6c757d; margin-bottom:20px;">Please select your role and login.</p>

            <?php if ($success): ?>
                <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error">⚠️ <?= $error ?></div>
            <?php endif; ?>

            <!-- Role Tabs -->
            <div class="role-tabs">
                <button class="role-tab <?= $selectedRole === 'user'  ? 'active' : '' ?>"
                        onclick="setRole('user')"  type="button">🏠 Citizen</button>
                <button class="role-tab <?= $selectedRole === 'donor' ? 'active' : '' ?>"
                        onclick="setRole('donor')" type="button">🤝 Donor</button>
                <button class="role-tab <?= $selectedRole === 'admin' ? 'active' : '' ?>"
                        onclick="setRole('admin')" type="button">🛡️ Admin</button>
                <button class="role-tab <?= $selectedRole === 'rider' ? 'active' : '' ?>"
                        onclick="setRole('rider')" type="button">🚴 Rider</button>
            </div>

            <!-- Login Form -->
            <form method="POST" action="login.php" id="loginForm">
                <input type="hidden" name="role" id="roleInput" value="<?= $selectedRole ?>">

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-icon-wrapper">
                        <span>📧</span>
                        <input type="email" name="email" id="email"
                               placeholder="Enter your email"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                               required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-icon-wrapper">
                        <span>🔒</span>
                        <input type="password" name="password" id="password"
                               placeholder="Enter your password"
                               required>
                        <span class="toggle-password" onclick="togglePassword()">👁️</span>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    Login →
                </button>
            </form>

            <div class="auth-footer">
                Don't have an account?
                <a href="/free_medicine/register.php">Register here</a>
            </div>

            <!-- Role hint -->
            <div id="roleHint" style="margin-top:14px; padding:10px 14px;
                 background:#e8f5ee; border-radius:8px; font-size:12px; color:#2a7a4f;">
            </div>

        </div><!-- /auth-body -->
    </div><!-- /auth-card -->
</div><!-- /auth-wrapper -->

<script>
    const hints = {
        user:  '🏠 <strong>Citizen:</strong> Login to request free medicines.',
        donor: '🤝 <strong>Donor:</strong> Login to donate medicines to those in need.',
        admin: '🛡️ <strong>Admin:</strong> Login to manage the system.',
        rider: '🚴 <strong>Rider:</strong> Login to manage deliveries.'
    };

    function setRole(role) {
        document.getElementById('roleInput').value = role;
        document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
        event.target.classList.add('active');
        document.getElementById('roleHint').innerHTML = hints[role] || '';
    }

    function togglePassword() {
        const pwd = document.getElementById('password');
        pwd.type = pwd.type === 'password' ? 'text' : 'password';
    }

    // Show hint on load
    document.getElementById('roleHint').innerHTML =
        hints['<?= $selectedRole ?>'] || hints['user'];
</script>
</body>
</html>
