<?php
// ============================================================
// config/db.php
// Database Connection — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // XAMPP default
define('DB_PASS', '');           // XAMPP default (no password)
define('DB_NAME', 'free_medicine_db');
define('DB_CHARSET', 'utf8mb4');

// Build PDO DSN
$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // Throw exceptions on error
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // Return arrays by default
    PDO::ATTR_EMULATE_PREPARES   => false,                    // Use real prepared statements
];

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // Show friendly error (hide details in production)
    die('<div style="font-family:sans-serif; padding:20px; color:red;">
        <h3>Database Connection Failed</h3>
        <p>Make sure XAMPP MySQL is running and the database <b>free_medicine_db</b> exists.</p>
        <small>' . $e->getMessage() . '</small>
    </div>');
}
?>
