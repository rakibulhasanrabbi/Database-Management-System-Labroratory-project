<?php
// ============================================================
// register.php
// Registration Page — Free Medicine Distribution System
// Member 2: Authentication + Shared Backend
// ============================================================

require_once __DIR__ . '/includes/middleware.php';

// If already logged in, go to dashboard
redirectIfLoggedIn();

$error   = '';
$success = '';
$activeTab = $_POST['register_as'] ?? $_GET['type'] ?? 'user';

// ---- Handle form submission ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $registerAs = trim($_POST['register_as'] ?? 'user');
    $name       = trim($_POST['name']       ?? '');
    $phone      = trim($_POST['phone']      ?? '');
    $email      = trim($_POST['email']      ?? '');
    $password   = trim($_POST['password']   ?? '');
    $confirm    = trim($_POST['confirm']    ?? '');
    $address    = trim($_POST['address']    ?? '');
    $activeTab  = $registerAs;

    // ---- Validate ----
    if (empty($name) || empty($phone) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please enter a valid email address.';
    } elseif (!isValidPhone($phone)) {
        $error = 'Phone number must be 10–15 digits only.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // ---- Register ----
        if ($registerAs === 'user') {
            $result = registerUser($pdo, compact('name', 'phone', 'email', 'password', 'address'));
        } elseif ($registerAs === 'donor') {
            $donorType = sanitizeInput($_POST['donor_type'] ?? 'Individual');
            $result = registerDonor($pdo, compact('name', 'phone', 'email', 'password', 'address', 'donorType') + ['donor_type' => $donorType]);
        } else {
            $error = 'Invalid registration type.';
            $result = false;
        }

        if ($result === 'email_exists') {
            $error = 'An account with this email already exists. Please login.';
        } elseif ($result === false || $result === null) {
            $error = 'Registration failed. Please try again.';
        } else {
            // ✅ Success
            $label   = $registerAs === 'user' ? 'Citizen' : 'Donor';
            $success = "Your $label account has been created! You can now login.";
            // Clear form on success
            $name = $phone = $email = $address = '';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — Free Medicine Distribution</title>
    <link rel="stylesheet" href="/free_medicine/assets/css/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-card" style="max-width: 520px;">

        <!-- Header -->
        <div class="auth-header">
            <div class="logo">💊</div>
            <h1>Create an Account</h1>
            <p>Free Medicine Distribution System</p>
        </div>

        <!-- Body -->
        <div class="auth-body">

            <?php if ($success): ?>
                <div class="alert alert-success">
                    ✅ <?= htmlspecialchars($success) ?>
                    <br><a href="/free_medicine/login.php" style="font-weight:700;">→ Click here to Login</a>
                </div>
            <?php elseif ($error): ?>
                <div class="alert alert-error">⚠️ <?= $error ?></div>
            <?php endif; ?>

            <!-- Register As Tabs -->
            <div class="role-tabs" style="margin-bottom:20px;">
                <button class="role-tab <?= $activeTab === 'user'  ? 'active' : '' ?>"
                        onclick="switchTab('user')"  type="button">🏠 Register as Citizen</button>
                <button class="role-tab <?= $activeTab === 'donor' ? 'active' : '' ?>"
                        onclick="switchTab('donor')" type="button">🤝 Register as Donor</button>
            </div>

            <!-- COMMON FORM -->
            <form method="POST" action="register.php">
                <input type="hidden" name="register_as" id="registerAs" value="<?= htmlspecialchars($activeTab) ?>">

                <div class="form-group">
                    <label>Full Name <span style="color:red">*</span></label>
                    <input type="text" name="name" placeholder="Enter your full name"
                           value="<?= htmlspecialchars($name ?? '') ?>" required>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                    <div class="form-group">
                        <label>Phone <span style="color:red">*</span></label>
                        <input type="text" name="phone" placeholder="01XXXXXXXXX"
                               value="<?= htmlspecialchars($phone ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email <span style="color:red">*</span></label>
                        <input type="email" name="email" placeholder="your@email.com"
                               value="<?= htmlspecialchars($email ?? '') ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" placeholder="Your address (optional)"
                           value="<?= htmlspecialchars($address ?? '') ?>">
                </div>

                <!-- Donor type — only shown for donors -->
                <div class="form-group" id="donorTypeGroup"
                     style="display: <?= $activeTab === 'donor' ? 'block' : 'none' ?>;">
                    <label>Donor Type <span style="color:red">*</span></label>
                    <select name="donor_type">
                        <option value="Individual">Individual</option>
                        <option value="Pharmacy">Pharmacy</option>
                        <option value="Organization">Organization / NGO</option>
                    </select>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                    <div class="form-group">
                        <label>Password <span style="color:red">*</span></label>
                        <input type="password" name="password" id="password"
                               placeholder="Min 6 characters" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label>Confirm Password <span style="color:red">*</span></label>
                        <input type="password" name="confirm" id="confirm"
                               placeholder="Repeat password" required>
                    </div>
                </div>

                <!-- Password match indicator -->
                <div id="matchMsg" style="font-size:12px; margin-top:-10px; margin-bottom:14px;"></div>

                <button type="submit" class="btn btn-primary" id="submitBtn">
                    Create Account →
                </button>
            </form>

            <div class="auth-footer">
                Already have an account? <a href="/free_medicine/login.php">Login here</a>
            </div>

        </div><!-- /auth-body -->
    </div>
</div>

<script>
    function switchTab(tab) {
        document.getElementById('registerAs').value = tab;
        document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
        event.target.classList.add('active');

        const donorGroup = document.getElementById('donorTypeGroup');
        const submitBtn  = document.getElementById('submitBtn');

        if (tab === 'donor') {
            donorGroup.style.display = 'block';
            submitBtn.textContent = 'Register as Donor →';
        } else {
            donorGroup.style.display = 'none';
            submitBtn.textContent = 'Register as Citizen →';
        }
    }

    // Password match check
    document.getElementById('confirm').addEventListener('input', function () {
        const pwd  = document.getElementById('password').value;
        const conf = this.value;
        const msg  = document.getElementById('matchMsg');

        if (conf === '') {
            msg.innerHTML = '';
        } else if (pwd === conf) {
            msg.innerHTML = '<span style="color:green">✅ Passwords match</span>';
        } else {
            msg.innerHTML = '<span style="color:red">❌ Passwords do not match</span>';
        }
    });

    // Set initial button text
    document.getElementById('submitBtn').textContent =
        '<?= $activeTab === 'donor' ? 'Register as Donor →' : 'Register as Citizen →' ?>';
</script>
</body>
</html>
