<?php
require_once __DIR__ . '/../includes/middleware.php';
requireDonor();
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Dashboard</title>
    <link rel="stylesheet" href="/free_medicine/assets/css/style.css">
</head>
<body>

<div class="navbar">
    <div class="navbar-brand">💊 Free Medicine System</div>
    <div class="navbar-user">
        <span>👋 Hello, <?= htmlspecialchars($user['name']) ?></span>
        <span style="background:#ffffff33; padding:4px 10px; border-radius:20px; font-size:12px;">🤝 Donor</span>
        <a href="/free_medicine/logout.php" style="color:white; font-size:13px;">Logout →</a>
    </div>
</div>

<div style="padding:40px; text-align:center;">
    <div style="background:white; border-radius:16px; padding:40px; max-width:500px; margin:0 auto; box-shadow:0 4px 20px rgba(0,0,0,0.1);">
        <div style="font-size:60px; margin-bottom:16px;">🤝</div>
        <h2 style="color:#2a7a4f; margin-bottom:10px;">Donor Login Successful!</h2>
        <p style="color:#666; margin-bottom:20px;">Member 2 এর Authentication System কাজ করছে!</p>

        <div style="background:#e8f5ee; border-radius:10px; padding:16px; text-align:left; margin-bottom:20px;">
            <p style="margin:6px 0; font-size:14px;">👤 <strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
            <p style="margin:6px 0; font-size:14px;">📧 <strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            <p style="margin:6px 0; font-size:14px;">🤝 <strong>Role:</strong> Donor</p>
        </div>

        <p style="font-size:13px; color:#888;">এই page টা Member 4 (Donor Module) replace করবে।</p>
        <br>
        <a href="/free_medicine/logout.php"
           style="background:#dc3545; color:white; padding:10px 24px; border-radius:8px; font-size:14px; font-weight:600;">
            Logout
        </a>
    </div>
</div>

</body>
</html>
